THE MISANTHROPIC COW HOOF GLOVE — FOUR-VIEW KIT
============================================================

Goal: four matching views of ONE left-hand glove (back of hand, little-finger side, thumb side, palm) for Tripo multiview. Three are generated in ChatGPT; the palm view is a mirror of the back-of-hand view.
Work through STEP_1 to STEP_5 in order. Each package has a PROMPT.txt and the images to attach, numbered in attach order.
Works in ChatGPT image generation or Gemini. Use the same chat throughout unless told otherwise.

GROUND RULES:
  - One view per message. Never ask for a sheet or grid of views.
  - In ChatGPT, use the Select tool on the image to brush over only the wrong area before sending a fix. Then only that area is redrawn instead of the whole image.
  - If two fixes in a row make things worse, start a new chat: run Step 1 again, then attach your approved images and carry on from where you were.
  - Approve a view only after checking it against the design key. One wrong view teaches Tripo the wrong shape.

DESIGN_KEY.png is your checklist for every result.
