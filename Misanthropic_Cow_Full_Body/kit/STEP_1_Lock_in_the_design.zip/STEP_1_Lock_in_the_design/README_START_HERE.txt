THE MISANTHROPIC COW: FULL COSTUME, FOUR-VIEW KIT (v2)
============================================================

Goal: one clean, full-length image of the complete cow costume with nothing worn over it (the FRONT view), then matching back and side views for Tripo multiview.
Work through STEP_1 to STEP_5 in order (STEP_2B only if Step 2 is blocked). Each package has a PROMPT.txt and the images to attach, numbered in attach order.
Works in ChatGPT image generation. Use the same chat throughout unless told otherwise.

GROUND RULES:
  - One view per message. Never ask for a sheet or grid of views.
  - In ChatGPT, use the Select tool on the image to brush over only the wrong area before sending a fix. Then just that area is redrawn instead of the whole image.
  - If two fixes in a row make things worse, start a new chat: run Step 1 again, then attach your approved images and carry on from where you were.
  - Approve a view only after checking it against the design key. One wrong view teaches Tripo the wrong shape.
  - Guardrail message? Start a new chat (see Fix K). If Step 2 is blocked twice, use STEP_2B: it edits a flat-colour drawing instead of the photo collage.
  - The close-ups of the udder and the bloomers are left out of the kit on purpose, because close-ups like those are the most likely to trip the filter. Both show clearly enough in the whole-costume photos.

DESIGN_KEY_check_every_view_against_this.png is your checklist for every result.
