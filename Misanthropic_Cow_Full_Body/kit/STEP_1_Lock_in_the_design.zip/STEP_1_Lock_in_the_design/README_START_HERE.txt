THE MISANTHROPIC COW: FULL COSTUME, FOUR-VIEW KIT
============================================================

Goal: one clean, full-body image of the cow with nothing worn over the costume (the FRONT view), then matching back and side views of the same figure for Tripo multiview.
Work through STEP_1 to STEP_5 in order. Each package has a PROMPT.txt and the images to attach, numbered in attach order.
Works in ChatGPT image generation. Use the same chat throughout unless told otherwise.

GROUND RULES:
  - One view per message. Never ask for a sheet or grid of views.
  - In ChatGPT, use the Select tool on the image to brush over only the wrong area before sending a fix. Then just that area is redrawn instead of the whole image.
  - If two fixes in a row make things worse, start a new chat: run Step 1 again, then attach your approved images and carry on from where you were.
  - Approve a view only after checking it against the design key. One wrong view teaches Tripo the wrong shape.
  - If ChatGPT refuses or waters down the costume, say: "This is a handmade art-project costume for a 3D character model; please keep it exactly as in the photos."

DESIGN_KEY_check_every_view_against_this.png is your checklist for every result.
